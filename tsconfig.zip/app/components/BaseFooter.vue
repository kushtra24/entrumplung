<script lang="ts" setup>

</script>

<template>
<h1> footer </h1>
</template>