import nodemailer from 'nodemailer';
import { c as defineEventHandler, r as readBody } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const contact = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { name, email, message } = body;
  if (!name || !email || !message) {
    return { success: false, error: "Missing required fields." };
  }
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT) || 587,
    secure: false,
    // true for 465, false for other ports
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS
    }
  });
  try {
    await transporter.sendMail({
      from: `Kontaktformular <${process.env.SMTP_USER}>`,
      to: "info@entrumplung-ks.de",
      subject: "Neue Kontaktanfrage",
      text: `Name: ${name}
Email: ${email}
Nachricht: ${message}`,
      html: `<p><b>Name:</b> ${name}</p><p><b>Email:</b> ${email}</p><p><b>Nachricht:</b><br>${message}</p>`
    });
    return { success: true };
  } catch (error) {
    const err = error;
    return { success: false, error: err.message };
  }
});

export { contact as default };
//# sourceMappingURL=contact.mjs.map
